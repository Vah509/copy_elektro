import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';

export default defineConfig({
  output: 'static',
  
  // Прописали домен напрямую строкой
  site: 'https://elektroschit.com.ua', 
  
  // Включили генерацию карты сайта
  integrations: [sitemap()],
});